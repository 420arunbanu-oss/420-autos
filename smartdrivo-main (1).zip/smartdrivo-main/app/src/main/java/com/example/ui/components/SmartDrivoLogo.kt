package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R

/**
 * SmartDrivo brand logo.
 *
 * This component is used by Home and Splash, so changing it updates the
 * main SmartDrivo branding without touching unrelated UI logic.
 */
@Composable
fun SmartDrivoLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    showBorder: Boolean = true
) {
    val shape = RoundedCornerShape(percent = 22)

    Box(
        modifier = modifier
            .size(size)
            .then(
                if (showBorder) {
                    Modifier.border(
                        width = if (size > 60.dp) 2.dp else 1.dp,
                        color = Color(0xFF1E88E5).copy(alpha = 0.45f),
                        shape = shape
                    )
                } else Modifier
            )
            .clip(shape),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.smartdrivo_brand_logo),
            contentDescription = "SmartDrivo logo",
            modifier = Modifier.size(size),
            contentScale = ContentScale.Crop
        )
    }
}